since the program need some other files to run (they are not in the folder "RescueLineMondialiiV1" ) i put this files in "oder files"
the file "correzione luci.png" is in the desktop
the file "wifi.py" is olso in the desktop and automatically run every time the raspberry boot
the file "ssdlite_mobiledet_mask_edgetpu (5).tflite" is in the download folder