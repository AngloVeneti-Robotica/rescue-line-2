import os
import time


cmd = 'sudo rfkill unblock wifi'
os.system(cmd)

