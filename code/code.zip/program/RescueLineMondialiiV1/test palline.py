from detector2 import palline
from cattura import avvioStreamHD
import cv2
import time
avvioStreamHD()
#CameraSU()

while(1):
    t1=time.time()
    stato,posizione,dim,img,tipo=palline()
    cv2.imshow('img',img)
    cv2.waitKey(1)&0xff
    print(1/(time.time()-t1))
    
    print(posizione,dim,stato)