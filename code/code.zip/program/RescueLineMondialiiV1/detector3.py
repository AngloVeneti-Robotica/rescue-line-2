import cv2
import logging
import datetime
import time
import edgetpu.detection.engine
from PIL import Image
from cattura import foto

from cattura import foto
import numpy as np
#from stampa import stampa
from threading import Thread


#model='/home/pi/Desktop/full TPU+ new verde/modello/razzismo.tflite'
label='/home/pi/Desktop/full TPU+ new verde/modello/labels_map.txt'
#model='/home/pi/Downloads/output_tflite_graph_edgetpu.tflite'
model = '/home/pi/Downloads/ssdlite_mobiledet_mask_edgetpu (5).tflite'

width=800
height=600

# initialize TensorFlow models
with open(label, 'r') as f:
    pairs = (l.strip().split(maxsplit=1) for l in f.readlines())
    labels = dict((int(k), v) for k, v in pairs)

# initial edge TPU engine
logging.info('Initialize Edge TPU with model %s...' % model)
engine = edgetpu.detection.engine.DetectionEngine(model)
min_confidence = 0.6
#min_confidence = 0.3
num_of_objects = 5
logging.info('Initialize Edge TPU with model done.')




def palline():
    frame=foto()
    logging.debug('Detecting objects...')
    
    # call tpu for inference
    start_ms = time.time()
    frame_RGB = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img_pil = Image.fromarray(frame_RGB)
    objects = engine.detect_with_image(img_pil, threshold=min_confidence, keep_aspect_ratio=False,
                                     relative_coord=False, top_k=num_of_objects)

    
    
    bianca=(0,0)
    nera=(0,0)
    ostacolo=(0,0)
    
    maxBianca=0
    maxNera=0
    maxOstacolo=0
    
    
    if objects:
        for obj in objects:
            
            TipoPallina= obj.label_id
            score= obj.score
            
            box = obj.bounding_box
            ymin = int(box[0][1])
            xmin = int(box[0][0])
            ymax = int(box[1][1])
            xmax = int(box[1][0])
            
            x=(xmax+xmin)/2
            
            if(TipoPallina == 2):
                y=ymax
            else:
                y=(ymax+ymin)/2
                
            
            
            
            if(TipoPallina==0):
                #pallina bianca
                if(ymax>maxBianca):
                    bianca=(y,x)
                    maxBianca = ymax
                
            else:
                if(TipoPallina==1):
                    #pallina nera
                    if(score>maxNera):
                        nera=(y,x)
                        maxNera = score
                        
                
                
                else:
                    #ostacolo
                    if(score>maxOstacolo):
                        ostacolo=(y,x)
                    
            
            cv2.rectangle(frame, (xmin,ymin), (xmax,ymax), (10, 255, 0), 2)
            
        return frame, bianca, nera, ostacolo
    else:
        #logging.debug('No object detected')
        return frame, bianca, nera, ostacolo
    #cv2.imshow('Detected Objects', frame)

    #return frame


